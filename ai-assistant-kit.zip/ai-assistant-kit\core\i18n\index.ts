export * from './locales.ts';
